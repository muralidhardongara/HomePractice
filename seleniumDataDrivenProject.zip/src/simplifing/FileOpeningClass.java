package simplifing;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FileOpeningClass {

	XSSFWorkbook wb;
	XSSFSheet sheet;
	public FileOpeningClass(String path)
	
	{
		
		try {
			
				File src=new File(path);
				FileInputStream fis=new FileInputStream(src);
			 	wb=new XSSFWorkbook(fis);
			 	System.out.println("before excel");
			 	
			 
			} catch (Exception e) {
			System.out.println(e.getMessage());
			}
	}
	
	
	public String getData(int sheetno,int row,int cellno ) 
	{
		sheet=wb.getSheetAt(sheetno);
		String data=sheet.getRow(row).getCell(cellno).getStringCellValue();
		return data;
	}
		
		
		
}
