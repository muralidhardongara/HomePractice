package simplifing;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataDriven {
	
	XSSFWorkbook wb;
	XSSFSheet sheet;
	public void FileOpeningClass(String path)
	
	{
		
		try {
			
				File src=new File(path);
				FileInputStream fis=new FileInputStream(src);
			 	wb=new XSSFWorkbook(fis);
			 	System.out.println("before excel");
			 	
			 
			} catch (Exception e) {
			System.out.println(e.getMessage());
			}
	}
	
	public String getData(int sheetno) 
	{
		String data="";
		sheet=wb.getSheetAt(sheetno);
		int n=wb.getSheetAt(sheetno).getLastRowNum();
		for(int i=0;i<=n;i++) 
		{
			data=sheet.getRow(i).getCell(0).getStringCellValue();
		}
		return data;
	}

}
