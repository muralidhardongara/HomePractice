package seleniumDataDrivenProject;

import org.testng.annotations.Test;

import simplifing.FileOpeningClass;

public class SimpleGettingDataFromExcel {

	@Test
	public void reading()
	{
		FileOpeningClass op=new FileOpeningClass("C:\\murali\\excel.xlsx");
		System.out.println(op.getData(0,0,0));
		
	}
}
