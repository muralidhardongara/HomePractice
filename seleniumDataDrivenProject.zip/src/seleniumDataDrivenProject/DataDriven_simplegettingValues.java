package seleniumDataDrivenProject;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class DataDriven_simplegettingValues {
	
	@Test
	public void ReadingData() throws Exception {

	File src=new File("C:\\murali\\excel.xlsx");
	FileInputStream fis=new FileInputStream(src);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	System.out.println("before excel");
	XSSFSheet sheet=wb.getSheetAt(0);
	
	String data=sheet.getRow(0).getCell(0).getStringCellValue();
	System.out.println("data is:"+data);
	
	String data1=sheet.getRow(0).getCell(1).getStringCellValue();
	System.out.println("data is:"+data1);
	
	wb.close();
	
	}
}
