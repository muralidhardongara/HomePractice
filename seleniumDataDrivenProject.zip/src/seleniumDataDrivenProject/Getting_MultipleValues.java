package seleniumDataDrivenProject;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class Getting_MultipleValues {

	@Test
	public void ReadingData() throws Exception {

	File src=new File("C:\\murali\\excel.xlsx");
	FileInputStream fis=new FileInputStream(src);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	System.out.println("before excel");
	XSSFSheet sheet=wb.getSheetAt(0);
	
	int n=sheet.getLastRowNum();
	System.out.println("total row are:"+(n+1));
	
	for(int i=0;i<=n;i++) 
	{
	String data =	sheet.getRow(i).getCell(0).getStringCellValue();
	System.out.println("data is:"+data);
	}
	
	wb.close();
	}
	
	
}
