package seleniumDataDrivenProject;

import org.testng.annotations.Test;

import simplifing.DataDriven;

public class MultipleSimpleGettingDataFromExcel {

	@Test
	public void reading()
	{
		DataDriven op=new DataDriven();
		op.FileOpeningClass("C:\\murali\\excel.xlsx");
		System.out.println(op.getData(0));
		
		
	}
}
