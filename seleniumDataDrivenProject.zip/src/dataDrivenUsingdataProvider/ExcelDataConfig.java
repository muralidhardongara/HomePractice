package dataDrivenUsingdataProvider;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelDataConfig {
	
	XSSFWorkbook wb;
	XSSFSheet sheet;
	public ExcelDataConfig(String excelpath) 
	{
		try {
			File src=new File(excelpath);
			FileInputStream fis=new FileInputStream(src);
			wb=new XSSFWorkbook(fis);
			
			} 
		catch (Exception e) {
				e.printStackTrace();
			}
	}
	
	public String getData(int sheetno,int row,int column) 
	{
		sheet=wb.getSheetAt(sheetno);
		String data=sheet.getRow(row).getCell(column).getStringCellValue();
		return data;
	}
	
	public int getRowCount(int sheetno) 
	{
		int row=wb.getSheetAt(sheetno).getLastRowNum();
		row=row+1;
		return row;
	}

}
 