package DDTExcel;

import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Excel {
 
	WebDriver driver;
	XSSFWorkbook wb;
	Sheet sheet;
	
	@Test
	public void Excelsheet() throws Exception 
	{
		File src=new File("C:\\murali\\excel.xlsx");
		FileInputStream fis=new FileInputStream(src);
		wb=new XSSFWorkbook(fis);
		sheet=wb.getSheetAt(0);
		int n=sheet.getLastRowNum();
		
		for(int i=0;i<=n;i++) 
		{
			Row row=sheet.getRow(i);
			String uname=row.getCell(0).getStringCellValue();
			String pswd=row.getCell(1).getStringCellValue();
			
			System.setProperty("webdriver.chrome.driver", "C:\\murali\\chromedriver_win32\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
			driver.get("https://www.facebook.com");
			driver.findElement(By.name("email")).sendKeys(uname);
			driver.findElement(By.id("pass")).sendKeys(pswd);
			Thread.sleep(2000);
			driver.findElement(By.id("u_0_2")).click();
			driver.quit();
			
		}
		
		
	}
}
